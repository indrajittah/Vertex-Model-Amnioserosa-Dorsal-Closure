#include "std_include.h"

#include "cuda_runtime.h"
#include "cuda_profiler_api.h"

#define ENABLE_CUDA

//#include "Simulation.h"
//#include "voronoiQuadraticEnergy.h"
//#include "selfPropelledParticleDynamics.h"
#include "selfPropelledCellVertexDynamics.h"
#include "vertexQuadraticEnergy.h"
#include "DatabaseNetCDFSPV.h"
#include "DatabaseNetCDFAVM.h"
#include "EnergyMinimizerFIRE2D.h"
#include "DatabaseASCAVM.h"
//#include "noiseSource.h"
/*!
This file compiles to produce an executable that demonstrates how to use the energy minimization
functionality of cellGPU. Now that energy minimization behaves like any other equation of motion, this
demonstration is pretty straightforward
*/

//! A function of convenience for setting FIRE parameters
void setFIREParameters(shared_ptr<EnergyMinimizerFIRE> emin, Dscalar deltaT, Dscalar alphaStart,
        Dscalar deltaTMax, Dscalar deltaTInc, Dscalar deltaTDec, Dscalar alphaDec, int nMin,
        Dscalar forceCutoff)
    {
    emin->setDeltaT(deltaT);
    emin->setAlphaStart(alphaStart);
    emin->setDeltaTMax(deltaTMax);
    emin->setDeltaTInc(deltaTInc);
    emin->setDeltaTDec(deltaTDec);
    emin->setAlphaDec(alphaDec);
    emin->setNMin(nMin);
    emin->setForceCutoff(forceCutoff);
    };

int serial;
int main(int argc, char*argv[]){

    sscanf(argv[1],"%d",&serial);
    //as in the examples in the main directory, there are a bunch of default parameters that
    //can be changed from the command line
    int numpts = 256;
    int USE_GPU = -1;
    int c;
    int tSteps = 800;
    int initSteps = 60000;
    int steptokill = 15;
    int remainder = 0;
    int Ingress_Step = 440;
    Dscalar dt = 0.01;
    Dscalar KA = 1.0;
    Dscalar KP = 1.0;
    Dscalar p0 = 4.50;
    Dscalar a0 = 1.0;
    Dscalar v0 = 0.0;
    Dscalar Dr = 0.0;
    Dscalar compressrate = 0.01;
    Dscalar stdP0 = 0.50;
    Dscalar stdA0 = 0.50;
    Dscalar SLOPE_PREF_PERI_CHANGE = 0.0005;
    Dscalar STD_CHANGE = 0.0005;
    Dscalar STD_CHANGE_AREA = 0.0005;
    Dscalar slope = 0.00225;
    int EQ_AFTER_EACHCOMPRESS = 1000;
    //Dscalar P_Periodic;
    int program_switch = 1;
    while((c=getopt(argc,argv,"n:g:I:Z:O:L:l:S:s:m:w:s:D:r:a:i:P:v:b:x:y:z:p:t:e:k:R:E:")) != -1)
        switch(c)
        {
            case 'n': numpts = atoi(optarg); break;
            case 't': tSteps = atoi(optarg); break;
            case 'I': Ingress_Step = atoi(optarg); break;
            case 'm': slope = atof(optarg); break;
	    case 'L': steptokill = atoi(optarg); break;
            case 'l': remainder = atoi(optarg); break;
            case 'g': USE_GPU = atoi(optarg); break;
            case 'i': initSteps = atoi(optarg); break;
            case 'z': program_switch = atoi(optarg); break;
            case 'e': dt = atof(optarg); break;
            case 'Z': STD_CHANGE = atof(optarg); break;
            case 'O': STD_CHANGE_AREA = atof(optarg); break;
            case 'p': p0 = atof(optarg); break;
            case 'w': SLOPE_PREF_PERI_CHANGE = atof(optarg); break;
            case 'S': stdP0 = atof(optarg); break;
            case 's': stdA0 = atof(optarg); break;
            case 'k': KA = atof(optarg); break;
            case 'D': Dr = atof(optarg); break;
            case 'E': EQ_AFTER_EACHCOMPRESS = atoi(optarg); break;
            case 'R': compressrate = atof(optarg); break;
            case 'P': KP = atof(optarg); break;
            case 'a': a0 = atof(optarg); break;
            case 'v': v0 = atof(optarg); break;
            case '?':
                    if(optopt=='c')
                        std::cerr<<"Option -" << optopt << "requires an argument.\n";
                    else if(isprint(optopt))
                        std::cerr<<"Unknown option '-" << optopt << "'.\n";
                    else
                        std::cerr << "Unknown option character.\n";
                    return 1;
            default:
                       abort();
        };

    clock_t t1,t2;
    bool reproducible = false;
    bool initializeGPU = false;
    if (USE_GPU >= 0)
        {
        bool gpu = chooseGPU(USE_GPU);
        if (!gpu) return 0;
        cudaSetDevice(USE_GPU);
        }
    else
        initializeGPU = false;
    cout<<"Area Modulus "<<KA<<endl;
    cout<<"Perimeter Modulus "<<KP<<endl;
    cout<<"Compression amount "<<compressrate<<endl;
    cout<<"STD of PERI "<<stdP0<<endl;
    cout<<"STD of AREA "<<stdA0<<endl;
    cout<<"remainder = "<<remainder<<endl;
    cout<<"Ingress start from this step "<<Ingress_Step<<endl;
/*    FILE *data;//remove now i am checking
    FILE *data1;
    char dataname[256];
    char dataname1[256];*/


//#ifdef ITAH1
    //program_switch == 1 --> vertex model
    if(program_switch == 1){
    	char dataname[256];
    	sprintf(dataname,"vertex.nc");
	int Nvert = 2*numpts;
	AVMDatabaseNetCDF ncdat(Nvert,dataname,NcFile::Replace); //open
	bool runSPV = false;
	EOMPtr spp = make_shared<selfPropelledCellVertexDynamics>(numpts,Nvert);
        shared_ptr<VertexQuadraticEnergy> avm = make_shared<VertexQuadraticEnergy>(numpts,1.0,p0,reproducible,runSPV);
	shared_ptr<EnergyMinimizerFIRE> fireMinimizer = make_shared<EnergyMinimizerFIRE>(avm);
	/*Polydispersity in preferred perimeter*/
//	avm->setCellPreferencespoly(a0,p0,stdP0);
	avm->setCellPreferencespoly(a0,p0,stdP0,stdA0);
	/* monodisperse in preferred perimeter*/
	//avm->setCellPreferencesUniform(1.0,p0);
	
	avm->setModuliUniform(KA,KP);
	avm->setv0Dr(v0,Dr);
	avm->setT1Threshold(0.00001);
    	vector<int> vi(3*Nvert);
    	vector<int> vf(3*Nvert);

        ArrayHandle<int> vcn(avm->vertexCellNeighbors);
        for (int ii = 0; ii < 3*Nvert; ++ii){
		vi[ii]=vcn.data[ii];
        }
	//combine the equation of motion and the cell configuration in a "Simulation"
    	SimulationPtr sim = make_shared<Simulation>();
    	sim->setConfiguration(avm);
//    	sim->addUpdater(spp,avm);
	sim->addUpdater(fireMinimizer,avm);
	sim->setIntegrationTimestep(dt);
    	sim->setCPUOperation(!initializeGPU);
    	sim->setReproducible(reproducible);
        Dscalar mf;
	avm->reportMeanVertexForce();
	vector<int> TYPE;
        for (int i=0; i<numpts; i++){
                TYPE.push_back(i);
        }
        avm->setCellType(TYPE);
	//ncdat.WriteState(avm);
        printf("Start Minimizing\n");
        for (int i = 0; i <initSteps;++i){
		setFIREParameters(fireMinimizer,dt,0.99,0.1,1.1,0.95,.9,4,1e-12);
                fireMinimizer->setMaximumIterations(50*(i+1));
                sim->performTimestep();
                cout<<"tsteps"<<i<<endl;
                mf = fireMinimizer->getMaxForce();
                cout<<mf<<endl;
	if (mf < 1e-2)
                      break;
        }
        printf("minimized value of q = %f\n",avm->reportq());	
	avm->reportMeanVertexForce();
	//ncdat.WriteState(avm);
    	cout << "Mean q = " << avm->reportq() << endl;
	
//I will start to compress with vertex model
	avm->setT1Threshold(0.00001);
        Dscalar x11,x12,x21,x22;
	AVMDatabaseASC ascdat;
    	FILE *data1;
	FILE *data2;
	FILE *data3;
	FILE *data4;
	FILE *data5;
    	char dataname1[256];
    	char dataname2[256];
	char dataname3[256];
	char dataname4[256];
	char dataname5[256];
        char dir[128];
        sprintf(dir,"mkdir -p struct000");
        system(dir);
//        sprintf(dataname1,"struct000/areawithtime.txt");
//        data1 = fopen(dataname1,"w");
	Dscalar P0 = avm->HydrostaticPressure();
	ArrayHandle<Dscalar2> h_p(avm->AreaPeriPreferences,access_location::host,access_mode::read);
	FILE *fp1;
	fp1=fopen("PREF_AREA_PERI.dat","w");
	for(int k=0;k<numpts;k++){
        	//AreaPeriPref[k].x = PREF_AREA;
        	fprintf(fp1,"%f\t%f\n",h_p.data[k].x,h_p.data[k].y);
//                AreaPeriPref[k].y = h_p.data[k].y;
//                MEANPREFPERO += h_p.data[k].y;
        }
	//double PREFPERI[numpts];
        vector<double> PREFPERI(numpts);
	vector<double> PREFAREA(numpts);
        for(int k=0;k<numpts;k++){
                PREFPERI[k] = h_p.data[k].y;
		PREFAREA[k] = h_p.data[k].x;
        }
	vector<Dscalar2> AreaPeriPref(numpts);
        for(int k=0;k<numpts;k++){
                AreaPeriPref[k].x = PREFAREA[k];
                AreaPeriPref[k].y = PREFPERI[k];
        }
	std::cout << "PREF PERI VECTOR SIZE: "<<PREFPERI.size()<<endl;
	fclose(fp1);
	FILE *fp;
	fp=fopen("ALLSTUFF.dat","w");
	for(int ii = 0; ii < tSteps; ++ii){
                sim->performTimestep();
		int Nvertices = avm->getNumberOfDegreesOfFreedom();
                numpts = Nvertices/2;
                printf("Nvertices %d\t numpts %d\n",Nvertices,numpts);
		//ArrayHandle<Dscalar> h_s(avm->stress_ncells,access_location::host,access_mode::read);
                if(ii%20 == 0){
                        //ncdat.WriteState(avm);
			sprintf(dataname2,"struct000/instep%07ld.txt",ii);
                        data2 = fopen(dataname2,"w");
			sprintf(dataname1,"struct000/area%07ld.txt",ii);
        		data1 = fopen(dataname1,"w");
			sprintf(dataname3,"struct000/Linetesion%07ld.txt",ii);
                        data3 = fopen(dataname3,"w");
                        ascdat.WriteAreaAVM(avm,data1,numpts);
                        ascdat.WriteStateASCAVM(avm,data2,numpts);
			ascdat.WriteLinetensionAVM(avm,data3,numpts);
			fclose(data3);
                        fclose(data2);
                        fclose(data1);
		/*	std::vector<double> v;
			v = avm->Return_Normal_stress_due_to_its_neighborcells();	
			cout<<"v.size "<<v.size()<<endl;
			for(int l = 0; l<v.size(); l++){
				cout<<"Stress die to nn cells "<<v[l]<<endl;
			}	*/
                }
		/*   I wrote it in such a way that it will try to destroy any cell in the lowest area that is below a certain threshold value.*/
			//This will kill a cell if a cell below a certain threshold of area, then open it
//		if(avm->reportcellingressbelowthreshold_id() < (numpts-1)){
			//This will kill a cell at constant rate, for example 400, 420, 440, ... 
		if(avm->reportcellingressid() < (numpts-1) && ii>Ingress_Step && ii%steptokill==remainder){ //close it if you want to kill a cell below a certain threshold of area
//		if(avm->reportcellingressbelowthreshold_id() < (numpts-1) && ii>460 ){ //close it if you want to kill a cell below a certain threshold of area
			cout<<"if"<<"\t"<<ii<<endl;
			cout << "ingress step "<<ii<<endl;
			avm->setT1Threshold(0.00001);
                        int deadIdx = avm->reportcellingressid();
			//cout << "trying to killing cell " << deadIdx << AreaPeriPref[deadIdx].y << endl;
                        Nvertices = avm->getNumberOfDegreesOfFreedom();
                        numpts = Nvertices/2;

			ArrayHandle<Dscalar2> h_p(avm->AreaPeriPreferences,access_location::host,access_mode::read);
			ArrayHandle<Dscalar2> h_AP(avm->AreaPeri,access_location::host,access_mode::read);
			vector<Dscalar2> oldAP(numpts); 
			for(int k=0;k<numpts;k++){
				oldAP[k].x = h_p.data[k].x; 
				oldAP[k].y = h_p.data[k].y;
			} 

                        vector<Dscalar2> newPrefs(numpts);
			for(int k=0;k<numpts;k++){
				newPrefs[k].x = oldAP[k].x;
				newPrefs[k].y = oldAP[k].y;
			}

//                        vector<Dscalar2> newPrefs(numpts,oldAP);
                        newPrefs[deadIdx].x = 0.0;
                        newPrefs[deadIdx].y = 0.0;
			avm->setCellPreferences(newPrefs);
                        int cellVertices = 0;
			cout << "step "<<ii<<"trying to killing cell " << deadIdx <<" Actual Perimeter " << h_AP.data[deadIdx].y <<" Actual Area " << h_AP.data[deadIdx].x << "PREF AREA "<<oldAP[deadIdx].x <<"PREF PERI "<< oldAP[deadIdx].y << endl;
			//run for up to one tau to see if the cell shrinks to a triangle...if not, restore
			//////the area and perimeter preference to stop the simulation from becoming unstable
			for (int tt =0; tt < 50; ++tt){
                                ArrayHandle<int> cn(avm->cellVertexNum,access_location::host,access_mode::read);
                                cellVertices = cn.data[deadIdx];
                                if(cellVertices==3) break;
                                sim->performTimestep();
                        }
			if(cellVertices ==3){
                                cout << " successfully killing cell " << deadIdx <<endl;
                                avm->cellDeath(deadIdx);
				PREFPERI.erase (PREFPERI.begin()+deadIdx);
                        }
			
			else{
                                //Dscalar2 oldAP; oldAP.x=1.0; oldAP.y = p0;
                                //vector<Dscalar2> newPrefs(numpts,oldAP);
                                for(int k=0;k<numpts;k++){
                                	newPrefs[k].x = oldAP[k].x;
                                	newPrefs[k].y = oldAP[k].y;
                        	}
                                avm->setCellPreferences(newPrefs);
                        }

			/*Nvertices = avm->getNumberOfDegreesOfFreedom();
                        numpts = Nvertices/2;
			for (int tt =0; tt < 100; ++tt){
				sim->performTimestep();
                        }*/
/*
			cout << "killing cell " << deadIdx << endl;
			avm->cellDeath(deadIdx);
*/

			Nvertices = avm->getNumberOfDegreesOfFreedom();
                        numpts = Nvertices/2;
                        avm->Box->getBoxDims(x11,x12,x21,x22);
			x22=x22-compressrate;
			x21=x21+compressrate;
			avm->Box->setGeneral(x11,x12,x21,x22);
			Dscalar PREF_AREA = (abs(x11-x12)*abs(x22-x21))/numpts;
//	                ArrayHandle<Dscalar2> h_p(avm->AreaPeriPreferences,access_location::host,access_mode::read);
//        	        vector<Dscalar2> AreaPeriPref(numpts);
                	Dscalar MEANPREFPERO = 0;
                	Dscalar MEANPREFAREA = 0;
			Dscalar STDPREF_PERI = 0;
			//myvector.erase (PREFPERI.begin()+5);
			std::cout <<"PREF PERI VECTOR SIZE: "<<PREFPERI.size()<<endl;
			for(int k=0;k<numpts;k++){
//				AreaPeriPref[k].x = 1.0;
				AreaPeriPref[k].x = AreaPeriPref[k].x;
//				AreaPeriPref[k].y = PREFPERI[k];
//				AreaPeriPref[k].y = PREFPERI[k] - (slope*(0.0002/sqrt(numpts))*(0.0002/sqrt(numpts))*(double)(ii+1));
				AreaPeriPref[k].y = AreaPeriPref[k].y - (slope*(0.0002/sqrt(numpts))*(0.0002/sqrt(numpts)));
//				AreaPeriPref[k].y = AreaPeriPref[k].y - slope;
				MEANPREFAREA += AreaPeriPref[k].x;
	                        MEANPREFPERO += AreaPeriPref[k].y;

			}

			for(int k=0;k<numpts;k++){
                        	STDPREF_PERI +=  (AreaPeriPref[k].y-(MEANPREFPERO/(Dscalar)numpts))*(AreaPeriPref[k].y-(MEANPREFPERO/(Dscalar)numpts));
                	}
//			cout<<"pagla2"<<endl;
			Dscalar MEANPREFPERI_AFTER_STD_SHIFT = 0;
	                Dscalar MEANPREFAREA_AFTER_STD_SHIFT = 0;
			for(int k=0;k<numpts;k++){
                        if( AreaPeriPref[k].y < (MEANPREFPERO/numpts)){
                                AreaPeriPref[k].y = AreaPeriPref[k].y + STD_CHANGE;
                        }
                        if( AreaPeriPref[k].y > (MEANPREFPERO/numpts)){
                                AreaPeriPref[k].y = AreaPeriPref[k].y - STD_CHANGE;
                        }
                        MEANPREFPERI_AFTER_STD_SHIFT += AreaPeriPref[k].y;

			if( AreaPeriPref[k].x < (MEANPREFAREA/numpts)){
                                AreaPeriPref[k].x = AreaPeriPref[k].x + STD_CHANGE_AREA;
			}
                        if( AreaPeriPref[k].x > (MEANPREFAREA/numpts)){
                                AreaPeriPref[k].x = AreaPeriPref[k].x - STD_CHANGE_AREA;
			}
                        MEANPREFAREA_AFTER_STD_SHIFT += AreaPeriPref[k].x;
                }

			avm->setCellPreferences(AreaPeriPref);

//#ifdef ITAH
			for (int i = 0; i < 6;++i){
                        	sim->addUpdater(fireMinimizer,avm);
                        	setFIREParameters(fireMinimizer,dt,0.99,0.1,1.1,0.95,.9,40,1e-12);
                        	fireMinimizer->setMaximumIterations(100*i);
                        	sim->performTimestep();
                        	mf = fireMinimizer->getMaxForce();
                        	cout<<"mf = "<<mf<<endl;
                        	if (mf < 1e-6)
                                	break;
                	}
//#endif
//	cout<<"pagla2"<<endl;
//If you opened the above minimizer then close this for loop
#ifdef ITAH
			for (int tt =0; tt < 50; ++tt){
				sim->performTimestep();
                        }
	cout<<"pagla2ver1"<<endl;
#endif

//#ifdef ITAH
			avm->getCellmajorandminoraxisCPU();
                	ArrayHandle<Dscalar2> h_pos(avm->cellPositions);
                	Dscalar MEANAR=0;
                	Dscalar STDAR=0;
               	 	Dscalar STDPREF_AREA=0;
                	STDPREF_PERI=0;
                	for(int k=0; k <numpts;++k){
                        	int pidx = avm->tagToIdx[k];
                        	MEANAR += sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x);
                	}
                	MEANAR = MEANAR/(double)numpts;

			if(ii%20 == 0){
				sprintf(dataname4,"struct000/AR_%07ld.txt",ii);
                        	data4 = fopen(dataname4,"w");
				for(int k=0; k <numpts;++k){
                                	int pidx = avm->tagToIdx[k];
					fprintf(data4,"%lf\n",sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x));
				}
				fclose(data4);
			}

			if(ii%20 == 0){
                                avm->OOPCPU_Individual();
                                ArrayHandle<Dscalar2> h_pos(avm->cellPositions);
                                sprintf(dataname5,"struct000/OOP_%07ld.txt",ii);
                                data5 = fopen(dataname5,"w");
                                for(int k=0; k <numpts;++k){
                                        int pidx = avm->tagToIdx[k];
                                        fprintf(data5,"%lf\n",(h_pos.data[pidx].x));
                                }
                                fclose(data5);
                        }

                	for(int k=0; k <numpts;++k){
                        	int pidx = avm->tagToIdx[k];
                        	STDAR += (sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x)-MEANAR)*(sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x)-MEANAR);
                        	STDPREF_PERI +=  (AreaPeriPref[k].y-(MEANPREFPERI_AFTER_STD_SHIFT/(Dscalar)numpts))*(AreaPeriPref[k].y-(MEANPREFPERI_AFTER_STD_SHIFT/(Dscalar)numpts));
                        	STDPREF_AREA +=  (AreaPeriPref[k].x-(MEANPREFAREA_AFTER_STD_SHIFT/(Dscalar)numpts))*(AreaPeriPref[k].x-(MEANPREFAREA_AFTER_STD_SHIFT/(Dscalar)numpts));
                	}
			STDAR = sqrt(STDAR/(Dscalar)numpts);
//	                Dscalar2 variances = avm->reportVarAP_min_model();
			Dscalar2 variances = avm->reportVarAP();
//			fprintf(fp,"%d\t%d\t%f\t%f\t%.20f\t%.20f\t%.20f\t%.20f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",ii,numpts,(numpts-(abs(x11-x12)*abs(x22-x21)))/numpts,(abs(x11-x12)*abs(x22-x21)),avm->reportMeanA(),avm->reportMeanP(),variances.x,variances.y,avm->reportq(),avm->computeEnergy(),MEANAR,STDAR,avm->NormalStress(),avm->HydrostaticPressure(),avm->NormalInterstress(),MEANPREFPERO/numpts,MEANPREFAREA/numpts,avm->OOPCPU());
			fprintf(fp,"%d\t%d\t%f\t%f\t%.20f\t%.20f\t%.20f\t%.20f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",ii,numpts,(numpts-(abs(x11-x12)*abs(x22-x21)))/numpts,(abs(x11-x12)*abs(x22-x21)),avm->reportMeanA(),avm->reportMeanP(),variances.x,variances.y,avm->reportq(),avm->reportStdq(),avm->computeEnergy(),MEANAR,STDAR,avm->NormalStress(),avm->HydrostaticPressure(),avm->NormalInterstress(),MEANPREFPERO/numpts,MEANPREFAREA/numpts,avm->OOPCPU());
//#endif
		}




		else{
			cout<<"else"<<endl;
			cout << "not ingress step "<<ii<<endl;
			avm->Box->getBoxDims(x11,x12,x21,x22);
			//cout<<x12<<"\t"<<x21<<endl;
                	//x11=x11-compressrate;
                	x22=x22-compressrate;
			//x12=x12+compressrate;
			x21=x21+compressrate;
			avm->Box->setGeneral(x11,x12,x21,x22);
			Dscalar PREF_AREA = (abs(x11-x12)*abs(x22-x21))/numpts;
                	ArrayHandle<Dscalar2> h_p(avm->AreaPeriPreferences,access_location::host,access_mode::read);
			//vector<Dscalar2> AreaPeriPref(numpts);
			Dscalar MEANPREFPERO = 0;
			Dscalar MEANPREFAREA = 0;
			Dscalar STDPREF_PERI=0;
			std::cout <<"PREF PERI VECTOR SIZE: "<<PREFPERI.size()<<endl;
			for(int k=0;k<numpts;k++){
                		//AreaPeriPref[k].x = 1.0;
				AreaPeriPref[k].x = AreaPeriPref[k].x;
         	       		//AreaPeriPref[k].y = h_p.data[k].y;
//				AreaPeriPref[k].y = PREFPERI[k] - (slope*(0.0002/sqrt(numpts))*(0.0002/sqrt(numpts))*(double)(ii+1));
				AreaPeriPref[k].y = AreaPeriPref[k].y - (slope*(0.0002/sqrt(numpts))*(0.0002/sqrt(numpts)));
				//cout<<"Slope "<<(slope*(0.0002/sqrt(numpts))*(0.0002/sqrt(numpts)))<<endl;
				//AreaPeriPref[k].y = AreaPeriPref[k].y - slope;
				MEANPREFAREA += AreaPeriPref[k].x;
				MEANPREFPERO += AreaPeriPref[k].y;
        		}
//		cout<<MEANPREFPERO/numpts<<"\t"<<MEANPREFAREA/numpts<<"\t"<<"\t"<<sqrt(MEANPREFAREA/numpts)<<"\t"<<(MEANPREFPERO/numpts)/sqrt(MEANPREFAREA/numpts)<<endl;
			for(int k=0;k<numpts;k++){
        	                STDPREF_PERI +=  (AreaPeriPref[k].y-(MEANPREFPERO/(Dscalar)numpts))*(AreaPeriPref[k].y-(MEANPREFPERO/(Dscalar)numpts));

                	}
			Dscalar MEANPREFPERI_AFTER_STD_SHIFT = 0;
                	Dscalar MEANPREFAREA_AFTER_STD_SHIFT = 0;

			for(int k=0;k<numpts;k++){
                        	if( AreaPeriPref[k].y < (MEANPREFPERO/numpts)){
                                	AreaPeriPref[k].y = AreaPeriPref[k].y + STD_CHANGE;
                        	}
                        	if( AreaPeriPref[k].y > (MEANPREFPERO/numpts)){
                                	AreaPeriPref[k].y = AreaPeriPref[k].y - STD_CHANGE;
                        	}
                        	MEANPREFPERI_AFTER_STD_SHIFT += AreaPeriPref[k].y;


                        	if( AreaPeriPref[k].x < (MEANPREFAREA/numpts)){
					AreaPeriPref[k].x = AreaPeriPref[k].x + STD_CHANGE_AREA;
				}
                        	if( AreaPeriPref[k].x > (MEANPREFAREA/numpts)){
                         	       AreaPeriPref[k].x = AreaPeriPref[k].x - STD_CHANGE_AREA;
				}
                 	       MEANPREFAREA_AFTER_STD_SHIFT += AreaPeriPref[k].x;
                	}
		
			avm->setCellPreferences(AreaPeriPref);
//			avm->setCellPreferencespoly(PREF_AREA,p0,stdP0);
			//cout<<x22<<x21<<endl;
			//cout<<x11<<x12<<endl;
#ifdef ITAH
			for (int j = 0; j <EQ_AFTER_EACHCOMPRESS;++j){
				sim->performTimestep();
                	}
#endif
//#ifdef ITAH
			for (int i = 0; i <6;++i){
                        	sim->addUpdater(fireMinimizer,avm);
                        	setFIREParameters(fireMinimizer,dt,0.99,0.1,1.1,0.95,.9,40,1e-12);
                        	fireMinimizer->setMaximumIterations(50*i);
                        	sim->performTimestep();
                        	mf = fireMinimizer->getMaxForce();
				cout<<"mf = "<<mf<<endl;
				if (mf < 1e-6)
                                	break;
                	}
//#endif
//		Dscalar2 variances_old = avm->reportVarAP();
//#ifdef ITAH
	        	avm->getCellmajorandminoraxisCPU();
        		ArrayHandle<Dscalar2> h_pos(avm->cellPositions);
			Dscalar MEANAR=0;
			Dscalar STDAR=0;
			Dscalar STDPREF_AREA=0;
			STDPREF_PERI=0;
			for(int k=0; k <numpts;++k){
				int pidx = avm->tagToIdx[k];
				MEANAR += sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x); 
			}
			MEANAR = MEANAR/(double)numpts;


			if(ii%20 == 0){
                                sprintf(dataname4,"struct000/AR_%07ld.txt",ii);
                                data4 = fopen(dataname4,"w");
                                for(int k=0; k <numpts;++k){
                                        int pidx = avm->tagToIdx[k];
                                        fprintf(data4,"%lf\n",sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x));
                                }
                                fclose(data4);
                        }

			if(ii%20 == 0){
				avm->OOPCPU_Individual();
				ArrayHandle<Dscalar2> h_pos(avm->cellPositions);
                                sprintf(dataname5,"struct000/OOP_%07ld.txt",ii);
                                data5 = fopen(dataname5,"w");
                                for(int k=0; k <numpts;++k){
                                        int pidx = avm->tagToIdx[k];
                                        fprintf(data5,"%lf\n",(h_pos.data[pidx].x));
                                }
                                fclose(data5);
                        }

			



			for(int k=0; k <numpts;++k){
				int pidx = avm->tagToIdx[k];
				STDAR += (sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x)-MEANAR)*(sqrt(h_pos.data[pidx].y/h_pos.data[pidx].x)-MEANAR);
				STDPREF_PERI +=  (AreaPeriPref[k].y-(MEANPREFPERI_AFTER_STD_SHIFT/(Dscalar)numpts))*(AreaPeriPref[k].y-(MEANPREFPERI_AFTER_STD_SHIFT/(Dscalar)numpts));
				STDPREF_AREA +=  (AreaPeriPref[k].x-(MEANPREFAREA_AFTER_STD_SHIFT/(Dscalar)numpts))*(AreaPeriPref[k].x-(MEANPREFAREA_AFTER_STD_SHIFT/(Dscalar)numpts));
			}
			STDAR = sqrt(STDAR/(Dscalar)numpts);
//			Dscalar2 variances = avm->reportVarAP_min_model();
			Dscalar2 variances = avm->reportVarAP();
			//printf("%f\t%f\t%f\n",sqrt(STDPREF_PERI/(Dscalar)numpts),sqrt(STDPREF_AREA/(Dscalar)numpts),(MEANPREFPERO/numpts)/sqrt(MEANPREFAREA/numpts));
//			printf("%d\t%d\t%f\t%f\t%.20f\t%.20f\t%.20f\t%.20f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",ii,numpts,(numpts-(abs(x11-x12)*abs(x22-x21)))/numpts,(abs(x11-x12)*abs(x22-x21)),avm->reportMeanA_min_model()/numpts,avm->reportMeanP(),variances.x,variances.y,avm->reportq(),avm->computeEnergy(),MEANAR,STDAR,avm->NormalStress(),avm->HydrostaticPressure(),avm->NormalInterstress(),MEANPREFPERO/numpts,MEANPREFAREA/numpts,avm->OOPCPU(),(MEANPREFPERO/numpts)/sqrt(MEANPREFAREA/numpts));
			fprintf(fp,"%d\t%d\t%f\t%f\t%.20f\t%.20f\t%.20f\t%.20f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",ii,numpts,(numpts-(abs(x11-x12)*abs(x22-x21)))/numpts,(abs(x11-x12)*abs(x22-x21)),avm->reportMeanA(),avm->reportMeanP(),variances.x,variances.y,avm->reportq(),avm->reportStdq(),avm->computeEnergy(),MEANAR,STDAR,avm->NormalStress(),avm->HydrostaticPressure(),avm->NormalInterstress(),MEANPREFPERO/numpts,MEANPREFAREA/numpts,avm->OOPCPU());
			//printf("%d\t%d\t%f\t%f\t%.20f\t%.20f\t%.20f\t%.20f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",ii,numpts,(numpts-(abs(x11-x12)*abs(x22-x21)))/numpts,(abs(x11-x12)*abs(x22-x21)),avm->reportMeanA(),avm->reportMeanP(),variances.x,variances.y,avm->reportq(),avm->computeEnergy(),MEANAR,STDAR,avm->NormalStress(),avm->HydrostaticPressure(),avm->NormalInterstress(),MEANPREFPERO/numpts,MEANPREFAREA/numpts,avm->OOPCPU());
		//fprintf(fp,"%f\t%.20f\t%.20f\t%.20f\t%.20f\t%.20f\t%.20f\n",(numpts-(abs(x11-x12)*abs(x22-x21)))/numpts,avm->reportq(),avm->NormalInterstress(),avm->OOPCPU(),(MEANPREFPERO/numpts)/sqrt(MEANPREFAREA/numpts),MEANAR,STDAR);
//#endif
		}
	}
		fclose(fp);


    }
//#endif
    	if(initializeGPU)
        	cudaDeviceReset();
    		return 0;
}
