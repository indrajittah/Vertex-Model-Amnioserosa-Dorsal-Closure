#define ENABLE_CUDA
//#define ITAH
//#include "DatabaseNetCDFSPV.h"
#include "DatabaseASCAVM.h"
//#include "voronoiModelBase.h"
/*! \file DatabaseASCSPV.cpp */

// IT WRITE DATA IN ASCII FORMAT 
void AVMDatabaseASC::WriteStateASCAVM(STATE s, FILE *trajfile, int Nv)
    {
    std::vector<Dscalar> boxdat(4,0.0);
    Dscalar x11,x12,x21,x22;
    s->Box->getBoxDims(x11,x12,x21,x22);
    boxdat[0]=x11;
    boxdat[1]=x12;
    boxdat[2]=x21;
    boxdat[3]=x22;	
    //std::vector<Dscalar> posdat(2*Nv);
    //std::vector<Dscalar> directordat(Nv);
    std::vector<int> typedat(Nv);
    int idx = 0;
    Dscalar means0=0.0;

    //s->getCellPositionsCPU();
    s->getCellCentroidsCPU();
    ArrayHandle<Dscalar2> h_p(s->cellPositions);

    //ArrayHandle<Dscalar2> h_p(s->cellPositions,access_location::host,access_mode::read);
    //ArrayHandle<Dscalar> h_cd(s->cellDirectors,access_location::host,access_mode::read);
    ArrayHandle<int> h_ct(s->cellType,access_location::host,access_mode::read);
//    ArrayHandle<int> h_ex(s->exclusions,access_location::host,access_mode::read);
//	fprintf(trajfile,"%20.14f\t%20.14f\n",x11,x12);//Open if box length required
//	fprintf(trajfile,"%20.14f\t%20.14f\n",x21,x22); 
	fprintf(trajfile,"ITEM: TIMESTEP \n");
	fprintf(trajfile,"%08ld \n", 0);
	fprintf(trajfile,"ITEM: NUMBER OF ATOMS \n");
	fprintf(trajfile,"%08i \n", Nv);
	fprintf(trajfile,"ITEM: BOX BOUNDS xy xz yz pp pp pp \n");
	fprintf(trajfile,"%12.5f %12.5f %12.5f \n", boxdat[1], boxdat[0],0);
	fprintf(trajfile,"%12.5f %12.5f %12.5f \n", boxdat[2], boxdat[3],0);
	fprintf(trajfile,"-0.5 0.5 0.0 \n");

    
	fprintf(trajfile,"ITEM: ATOMS id type x y z radius\n");
	for (int ii = 0; ii < Nv; ++ii)
        {
        int pidx = s->tagToIdx[ii];
        //Dscalar px = h_p.data[pidx].x;
        //Dscalar py = h_p.data[pidx].y;
        //posdat[(2*idx)] = px;
        //posdat[(2*idx)+1] = py;
        //directordat[ii] = h_cd.data[pidx];
	//if(h_ex.data[ii] == 0)
	//	typedat[ii] = h_ct.data[pidx];
        //else
        //    typedat[ii] = h_ct.data[pidx]-5;
//        fprintf(trajfile,"%20.14f\t%20.14f\t%20.14f\t%d\n",h_p.data[pidx].x,h_p.data[pidx].y,h_cd.data[pidx]*(180 / 3.141592),typedat[ii]); //cell direction in radian
//	fprintf(trajfile,"%20.14f\t%20.14f\t%20.14f\t%d\n",h_p.data[pidx].x,h_p.data[pidx].y,h_cd.data[pidx],typedat[ii]);  //cell direction in degree
	//fprintf(trajfile,"%04i\t%04i\t%20.14f\t%20.14f\t%20.14f\t%20.14f\n",ii+1,1,h_p.data[pidx].x,h_p.data[pidx].y,0.1000,0.5000);
	fprintf(trajfile,"%04i\t%04i\t%20.14f\t%20.14f\t%20.14f\t%20.14f\n",ii+1,h_ct.data[pidx],h_p.data[pidx].x,h_p.data[pidx].y,0.1000,0.5000);
        idx +=1;
        };
    }

/*
void AVMDatabaseASC::WriteAreaAVM(STATE s, FILE *trajfile, int Nv)
    {
	ArrayHandle<Dscalar2> h_AP(s->AreaPeri,access_location::host,access_mode::read);
	for (int ii = 0; ii < Nv; ++ii){
		int pidx = s->tagToIdx[ii];
		fprintf(trajfile,"%20.14f\t",h_AP.data[pidx].x);
	}
	fprintf(trajfile,"\n");

    }
*/
void AVMDatabaseASC::WriteAreaAVM(STATE s, FILE *trajfile, int Nv)
    {
	s->getCellmajorandminoraxisCPU();
	ArrayHandle<Dscalar2> h_p(s->cellPositions);
   	ArrayHandle<int> h_ct(s->cellType,access_location::host,access_mode::read);
	ArrayHandle<Dscalar2> h_AP(s->AreaPeri,access_location::host,access_mode::read);
	ArrayHandle<Dscalar2> h_APpref(s->AreaPeriPreferences,access_location::host,access_mode::read);
        ArrayHandle<Dscalar2> h_KaKp(s->Moduli,access_location::host,access_mode::read);
	ArrayHandle<int> h_nn(s->cellVertexNum,access_location::host,access_mode::read);
	std::vector<double> Neighs_stress;
        Neighs_stress = s->Return_Normal_stress_due_to_its_neighborcells();
	std::vector<double> Cell_Line_tension;
        Cell_Line_tension = s->Return_Individual_Cell_Line_Tension();
        //cout<<"Neighs_stress.size "<<Neighs_stress.size()<<endl;
//	ArrayHandle<Dscalar> h_s(s->stress_ncells,access_location::host,access_mode::read);
#ifdef ITAH
	ArrayHandle<int> h_n(s->cellVertices,access_location::host,access_mode::read);
	std::vector<double> Normal_stress_individual_cell(Nv);
#endif
	for (int ii = 0; ii < Nv; ++ii){
                int pidx = s->tagToIdx[ii];
#ifdef ITAH
		Normal_stress_individual_cell[pidx] = (2.0*h_KaKp.data[pidx].x*(h_AP.data[pidx].x-h_APpref.data[pidx].x)) + ((1/h_AP.data[pidx].x)*h_KaKp.data[pidx].y*(h_AP.data[pidx].y-h_APpref.data[pidx].y)*h_AP.data[pidx].y);
		int neighs = h_nn.data[pidx];
//		printf("cell %d num of neighbour %d\n",pidx,neighs);
		for(int n = 0; n < neighs; ++n){
                        int vidx1 = h_n.data[n_idx(n,pidx)];
                        int vidx2 = 0;
                        int vertexNei_Cells_1st[3] = {0,0,0};
                        int vertexNei_Cells_2nd[3] = {0,0,0};
                        if(n+1 < neighs){
                                vidx2 = h_n.data[n_idx(n+1,pidx)];
			}




		}
#endif
                //fprintf(trajfile,"%04i\t%20.14f\t%20.14f\t%20.14f\t%20.14f\n",h_ct.data[pidx],h_AP.data[pidx].x,h_AP.data[pidx].y,h_p.data[pidx].x,h_p.data[pidx].y);
                //id,AREA,PERI,Shape Index,Normal interaction stress
//                fprintf(trajfile,"%04i\t%20.14f\t%20.14f\t%20.14f\t%20.14f\n",h_ct.data[pidx],h_AP.data[pidx].x,h_AP.data[pidx].y,h_AP.data[pidx].y/sqrt(h_AP.data[pidx].x),(2.0*h_KaKp.data[pidx].x*(h_AP.data[pidx].x-h_APpref.data[pidx].x)) + ((1/h_AP.data[pidx].x)*h_KaKp.data[pidx].y*(h_AP.data[pidx].y-h_APpref.data[pidx].y)*h_AP.data[pidx].y));
// 		id,cellneighbour,AREA,PERI,Shape Index,Normal area term, line tension term,Normal interaction stress, Neighbour stress
//                fprintf(trajfile,"%04i\t%04i\t%20.14f\t%20.14f\t%20.14f\t%20.14f\t%20.14f\t%20.14f\n",h_ct.data[pidx],h_nn.data[pidx],h_AP.data[pidx].x,h_AP.data[pidx].y,h_AP.data[pidx].y/sqrt(h_AP.data[pidx].x),(2.0*h_KaKp.data[pidx].x*(h_AP.data[pidx].x-h_APpref.data[pidx].x)), ((1/h_AP.data[pidx].x)*h_KaKp.data[pidx].y*(h_AP.data[pidx].y-h_APpref.data[pidx].y)*h_AP.data[pidx].y),(2.0*h_KaKp.data[pidx].x*(h_AP.data[pidx].x-h_APpref.data[pidx].x)) + ((1/h_AP.data[pidx].x)*h_KaKp.data[pidx].y*(h_AP.data[pidx].y-h_APpref.data[pidx].y)*h_AP.data[pidx].y));
                fprintf(trajfile,"%04i\t%04i\t%20.14f\t%20.14f\t%20.14f\t%20.14f\t%20.14f\t%20.14f\t%20.14f\t%20.14f\n",h_ct.data[pidx],h_nn.data[pidx],h_AP.data[pidx].x,h_AP.data[pidx].y,h_AP.data[pidx].y/sqrt(h_AP.data[pidx].x),(2.0*h_KaKp.data[pidx].x*(h_AP.data[pidx].x-h_APpref.data[pidx].x)), ((1/h_AP.data[pidx].x)*h_KaKp.data[pidx].y*(h_AP.data[pidx].y-h_APpref.data[pidx].y)*h_AP.data[pidx].y),(2.0*h_KaKp.data[pidx].x*(h_AP.data[pidx].x-h_APpref.data[pidx].x)) + ((1/h_AP.data[pidx].x)*h_KaKp.data[pidx].y*(h_AP.data[pidx].y-h_APpref.data[pidx].y)*h_AP.data[pidx].y),Neighs_stress[pidx],Cell_Line_tension[pidx]);
//                fprintf(trajfile,"%04i\t%20.14f\t%20.14f\t%20.14f\n",h_ct.data[pidx],h_AP.data[pidx].x,h_AP.data[pidx].y,sqrt(h_p.data[pidx].y/h_p.data[pidx].x));
        }
        //fprintf(trajfile,"\n");

    }


void AVMDatabaseASC::WriteLinetensionAVM(STATE s, FILE *trajfile, int Nv)
    {
	std::vector<double> Linetension;
        Linetension = s->Return_Linetension();
	cout<<"Line tension size = "<<Linetension.size()<<endl;
	for(int i=0;i<Linetension.size();i++){
		fprintf(trajfile,"%20.14f\n",Linetension[i]);		
	}
   
    } 
void AVMDatabaseASC::NormalStressValueAVM(STATE s, FILE *trajfile, int Nv){
        ArrayHandle<Dscalar2> h_AP(s->AreaPeri,access_location::host,access_mode::read);
        ArrayHandle<Dscalar2> h_APpref(s->AreaPeriPreferences,access_location::host,access_mode::read);
        ArrayHandle<Dscalar2> h_KaKp(s->Moduli,access_location::host,access_mode::read);
        Dscalar Hydr_Press = 0.0;
        Dscalar Edge_tension = 0.0;
        for (int i = 0; i < Nv; ++i){
//		TP = (-2.0*h_KaKp.data[i].x*h_AP.data[i].x*(h_AP.data[i].x  - h_APpref.data[i].x)) - (h_KaKp.data[i].y*h_AP.data[i].y*(h_AP.data[i].y  - h_APpref.data[i].y));
//		TP = (-2.0*h_KaKp.data[i].x*h_AP.data[i].x*(h_AP.data[i].x  - h_APpref.data[i].x));
		Hydr_Press = ( 2.0*h_KaKp.data[i].x*(h_AP.data[i].x  - h_APpref.data[i].x) * h_AP.data[i].x );
		Edge_tension = (h_KaKp.data[i].y*(h_AP.data[i].y  - h_APpref.data[i].y) * h_AP.data[i].y);
		//Hydrostatic pressure, Line tension, Total normal stress
		fprintf(trajfile,"%20.14f\t%20.14f\t%20.14f\n",Hydr_Press,Edge_tension,(Hydr_Press+Edge_tension));
	};
    }

/*
void AVMDatabaseASC::NormalStressValue_by_Neighbourcells_AVM(STATE s, FILE *trajfile, int Nv){
        ArrayHandle<Dscalar2> h_AP(s->AreaPeri,access_location::host,access_mode::read);
        ArrayHandle<Dscalar2> h_APpref(s->AreaPeriPreferences,access_location::host,access_mode::read);
        ArrayHandle<Dscalar2> h_KaKp(s->Moduli,access_location::host,access_mode::read);
	ArrayHandle<int> h_nn(s->cellVertexNum,access_location::host,access_mode::read);
        ArrayHandle<int> h_n(s->cellVertices,access_location::host,access_mode::read);
        ArrayHandle<int> h_vcn(s->vertexCellNeighbors,access_location::host,access_mode::read);
        Dscalar NS = 0.0;
	int avgNumNeigh=0;
        Dscalar Answer = 0.0;
        for (int i = 0; i < Nv; ++i){
                int neighs = h_nn.data[i];
		double Total_Line_Tension_Single_Cell = 0.0;
                for(int n = 0; n < neighs; ++n){
                        int vidx1 = h_n.data[n_idx(n,i)];
                        int vidx2 = 0;
                        int vertexNei_Cells_1st[3] = {0,0,0};
                        int vertexNei_Cells_2nd[3] = {0,0,0};
                        if(n+1 < neighs){
                                vidx2 = h_n.data[n_idx(n+1,i)];
			}
			else
                                vidx2 = h_n.data[n_idx(0,i)];
                        for (int ff = 0; ff < 3; ++ff){
                                vertexNei_Cells_1st[ff] = h_vcn.data[3*vidx1+ff];
                                vertexNei_Cells_2nd[ff] = h_vcn.data[3*vidx2+ff];
			}
                        vector<int> v(3 + 3);
                        vector<int>::iterator it, st;
                        sort(vertexNei_Cells_1st, vertexNei_Cells_1st + 3);
			sort(vertexNei_Cells_2nd, vertexNei_Cells_2nd + 3);
			it = set_intersection(vertexNei_Cells_1st, vertexNei_Cells_1st + 3, vertexNei_Cells_2nd, vertexNei_Cells_2nd + 3, v.begin());
			double LineTension_ab = 0.0;
                        for (st = v.begin(); st != it; ++st){
                                LineTension_ab += (h_AP.data[*st].y  - h_APpref.data[*st].y);
			}
				Total_Line_Tension_Single_Cell += LineTension_ab;
			}
			NS = (2.0*h_KaKp.data[i].x*h_AP.data[i].x*(h_AP.data[i].x  - h_APpref.data[i].x));
		}

	}
*/

/*
	for (int i = 0; i < Nv; ++i){
		int neighs = h_nn.data[i];
//		TP = (-2.0*h_KaKp.data[i].x*h_AP.data[i].x*(h_AP.data[i].x  - h_APpref.data[i].x)) - (h_KaKp.data[i].y*h_AP.data[i].y*(h_AP.data[i].y  - h_APpref.data[i].y));
//		TP = (-2.0*h_KaKp.data[i].x*h_AP.data[i].x*(h_AP.data[i].x  - h_APpref.data[i].x));
		Hydr_Press = ( 2.0*h_KaKp.data[i].x*(h_AP.data[i].x  - h_APpref.data[i].x) * h_AP.data[i].x );
		Edge_tension = (h_KaKp.data[i].y*(h_AP.data[i].y  - h_APpref.data[i].y) * h_AP.data[i].y);
		//Hydrostatic pressure, Line tension, Total normal stress
		fprintf(trajfile,"%20.14f\t%20.14f\t%20.14f\n",Hydr_Press,Edge_tension,(Hydr_Press+Edge_tension));
	};
    }
*/
